import User from "../models/userModel.js";
import Document from '../models/documentModel.js';
import catchAsyncError from "../utils/catchAsyncError.js";
import { s3Uploadv2 } from "../utils/s3.js";
import CryptoJS from "crypto-js";
import schedule from 'node-schedule';
import APIFeatures from "../features/apifeatures.js";


export const getProfile = catchAsyncError(async (req,res,next)=>{

    const userId = req.user.id;

    const user = await User.findById(userId);

    if(!user){
        return res.status(404).json({success: false, message: "user not found"});
    }

    res.status(200).json({success: true, user});

}); 


export const updateProfile = catchAsyncError(async (req, res, next) => {
    const userId = req.user.id;

    const updatedData = req.body;

    const updatedUser = await User.findByIdAndUpdate(userId, updatedData, {
        new: true, 
        runValidators: true, 
    });

    if (!updatedUser) {
        return res.status(404).json({ success: false, message: "User not found" });
    }

    res.status(200).json({ success: true, updatedUser });
});



export const getAllUsers = catchAsyncError(async (req, res) => {
  
    const apiFeature = new APIFeatures(User.find().sort({createdAt: -1}), req.query).search();

    let users = await apiFeature.query;
    let usersCount = users.length;
  
    // if (req.query.resultPerPage && req.query.currentPage) {
    //   apiFeature.pagination();
    //   guitars = await apiFeature.query.clone();
    // }  
  

    res.status(200).json({ success: true, users ,usersCount});
 });


//  export const uploadDocument = async (req, res, next) => {
//     try {
//       if (!req.pdfFile) {
//         return res.status(400).json({ success: false, message: 'No file uploaded' });
//       }
  
//       const file = req.pdfFile;
  
//       const s3Response = await s3Uploadv2(file);
  
//       const filePath = s3Response.Location;
  
//       req.filePath = filePath;
  
//       next(); 
//     } catch (error) {
//       console.error('Error uploading document:', error);
//       return res.status(500).json({ success: false, message: 'Internal Server Error' });
//     }
//   };
  

// export const uploadDocument = async (req, res, next) => {
//   try {
//     if (!req.pdfFile) {
//       return res.status(400).json({ success: false, message: 'No file uploaded' });
//     }

//     const encryptedFile = req.pdfFile; // Assuming req.pdfFile contains the encrypted file data
//     const secretKey = 'SecureDoc'; // Replace with the same secret key used for encryption

//     
//     const decryptedFile = CryptoJS.AES.decrypt(encryptedFile, secretKey);
    
//     
//     const decryptedBuffer = Buffer.from(decryptedFile.toString(CryptoJS.enc.Utf8), 'binary');

//     next();
//   } catch (error) {
//     console.error('Error decrypting document:', error);
//     return res.status(500).json({ success: false, message: 'Internal Server Error' });
//   }
// };

  

export const createDocument = async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ success: false, message: 'No file uploaded' });
    }

    const {hour,minute,sentTo} = req.body
    console.log("Hour min",hour,minute);
    // console.log("req file",req.file);

    const s3Response = await s3Uploadv2(req.file);

    // const expiresAt = new Date();
    // expiresAt.setHours(expiresAt.getHours() + 1);
    const expiresAt = new Date();
    expiresAt.setHours(expiresAt.getHours() + Number(hour)); 
    expiresAt.setMinutes(expiresAt.getMinutes() + Number(minute)); 


    const sentBy = req.user.id;
   console.log('sentTo:',sentTo);

    const newDocument = new Document({
      content: s3Response.Location, 
      sentBy,
      expiresAt,
      sentTo,
    });

    await newDocument.save();

    return res.status(201).json({
      success: true,
      message: 'Document created and uploaded successfully',
      document: newDocument,
    });
  } catch (error) {
    console.error('Error creating/uploading document:', error);
    return res.status(500).json({ success: false, message: 'Internal Server Error' });
  }
};


export const getAllUserDocuments = async (req, res) => {

      const userId = req.user.id;
  
      const userDocuments = await Document.find({ sentBy: userId }).populate('sentTo', 'firstname lastname email').sort({createdAt: -1});
  
      return res.status(200).json({ success: true, userDocuments });
    
    
  };

  
export const getInboxDocuments = async (req, res) => {

      const userId = req.user.id;
  
      const userDocuments = await Document.find({ sentTo: userId }).populate('sentBy', 'firstname lastname email').sort({createdAt: -1});
  
      return res.status(200).json({ success: true, userDocuments });
    
    
  };






 