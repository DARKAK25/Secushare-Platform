import multer from 'multer';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';
import fs from 'fs/promises';

// Get the current module's file path
const __filename = fileURLToPath(import.meta.url);
// Get the directory name of the current module
const __dirname = dirname(__filename);

// Configure multer storage and file filter
const storage = multer.diskStorage({
  destination: async (req, file, cb) => {
    // Specify the directory where you want to store the files locally
    const uploadDir = join(__dirname, '..', 'uploads');

    // Create the 'uploads' directory if it doesn't exist
    try {
      await fs.mkdir(uploadDir, { recursive: true });
    } catch (error) {
      console.error('Error creating upload directory:', error);
    }

    cb(null, uploadDir);
  },
  filename: (req, file, cb) => {
    // Generate a unique filename for each uploaded file
    const modifiedFileName = Date.now().toString() + '-' + file.originalname.replace(/ /g, '_');
    cb(null, modifiedFileName);
  },
});

const fileFilter = (req, file, cb) => {
  if (file.mimetype === 'application/pdf') {
    req.fileType = 'pdf'; // Set the fileType property in the request for future reference if needed
    cb(null, true);
  } else {
    cb(new multer.MulterError('LIMIT_UNEXPECTED_FILE'), false);
  }
};

 const upload = multer({
  storage,
  fileFilter,
  limits: { fileSize: 11006600, files: 1 },
}).single('pdfFile'); // 'pdfFile' should match the field name in the FormData on the frontend


export const uploadFile = (req, res) => {
  upload(req, res, (err) => {
    if (err instanceof multer.MulterError) {
      console.error('Multer error:', err);
      return res.status(400).json({ success: false, message: 'File upload error' });
    } else if (err) {
      console.error('Unknown error:', err);
      return res.status(500).json({ success: false, message: 'Internal server error' });
    }

    const filePath = req.file.path;
    console.log('File uploaded successfully:', filePath);


    res.status(200).json({ success: true, message: 'File uploaded successfully', filePath });
  });
};

// Controller function for handling file upload

