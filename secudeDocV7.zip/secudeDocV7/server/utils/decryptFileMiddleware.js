import CryptoJS from 'crypto-js';

export const decryptFileMiddleware = (req, res, next) => {
    try {


        console.log("req file ",req.file);
        console.log("req pdffile",req.pdfFile);
        console.log("req body",req.body);

      const encryptedFileBuffer = req.file.buffer;
  
      const secretKey = 'SecureDoc';
      const decryptedFile = CryptoJS.AES.decrypt(
        encryptedFileBuffer.toString('utf-8'),
        secretKey
      ).toString(CryptoJS.enc.Utf8);
  
      const decryptedBuffer = Buffer.from(decryptedFile, 'utf-8');
  
      req.file.buffer = decryptedBuffer;
      req.file.originalname = 'decrypted.pdf'; 
      req.file.encoding = 'utf-8';
      req.file.mimetype = 'application/pdf';
  
      next();
    } catch (error) {
      console.error("Error decrypting file:", error);
      res.status(500).send({ error: 'Internal server error' });
    }
  };
  