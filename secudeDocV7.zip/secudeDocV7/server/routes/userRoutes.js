import { Router } from "express";
import { createDocument, getAllUserDocuments, getAllUsers, getInboxDocuments, getProfile, updateProfile } from "../controllers/userController.js";
import { upload } from "../utils/s3.js";
import { decryptFileMiddleware } from "../utils/decryptFileMiddleware.js";
const router = Router();


router.get("/all-users", getAllUsers);
router.get("/profile", getProfile);
router.get("/documents", getAllUserDocuments);
router.get("/inbox", getInboxDocuments);
router.put("/profile", updateProfile);

router.post('/upload', upload.single('pdfFile'),createDocument);
// router.post('/upload',decryptFileMiddleware, upload.single('pdfFile'),createDocument);
// router.post("/doc",uploadDocument,createDocument);


export default router;
