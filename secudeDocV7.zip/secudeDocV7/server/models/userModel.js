import mongoose from "mongoose";

const userSchema = new mongoose.Schema({
    firstname: {
        type: String,
        required: true,
      },
      lastname: {
        type: String,
        required: true,
      },
      email: {
        type: String,
        required: true,
        unique: true,
        match: /^\S+@\S+\.\S+$/,
      },
      password: {
        type: String,
        required: true,
        minlength: 8, 
      },
      inboxCount: {
        type: Number,
        default:0,      
      },
      isAdmin:{
        type: Boolean,
        default: false,
      },
      documents: [
        {
          documentId: {
            type: mongoose.Schema.Types.ObjectId,
            ref: "document",
          },
          sentBy: {
            type: mongoose.Schema.Types.ObjectId,
            ref: "user",
          },
          sentAt: {
            type: Date,
            default: Date.now,
          },
        },
      ],
      
},{
    timestamps:true,
});

const userModel = mongoose.model("user",userSchema);

export default userModel;