import React from "react";
import { Col, Container, Row } from "react-bootstrap";
import { useSelector } from "react-redux";
import { Link } from "react-router-dom";
import Uploader from "../components/Uploader";

function HomePage() {
  const { token } = useSelector((state) => state.user);

  return (
    <section className="custom-section d-flex justify-content-center">
      <Container className="p-5 text-center">
        <Row>
          <Col data-aos="zoom-in" data-aos-duration="500" data-aos-delay="300">
            <h1
              className="display-5 fw-bold mb-5 text-white"
               style={{ textShadow: "0px 10px 10px red" }}
            >
              Welcome to Secure Doc
            </h1>
          </Col>
        </Row>

        {/* {token ? (
          <Uploader />
        ) : (
          <h4 className="my-3 text-white">
            Please <Link to={"/auth/login"}>Login</Link> to get started
          </h4>
        )} */}

       
      </Container>
    </section>
  );
}

export default HomePage;
