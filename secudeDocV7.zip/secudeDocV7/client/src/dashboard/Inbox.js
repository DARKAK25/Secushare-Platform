import React, { useState, useEffect, useRef } from 'react';
import { Button, Container, Table, Modal } from 'react-bootstrap';
import { useDispatch, useSelector } from 'react-redux';
import { hideLoading, showLoading } from '../features/loadingSlice';
import { getError } from '../utils/getError';
import toast from 'react-hot-toast';
import api from '../utils/axios';
import { PDFDocument, rgb } from 'pdf-lib'
import 'pdfjs-dist/webpack';
import 'pdfjs-dist/web/pdf_viewer.css';
import { Document, Page, pdfjs } from 'react-pdf';

pdfjs.GlobalWorkerOptions.workerSrc = 'pdf.worker.min.js';

function Inbox() {
  const { token } = useSelector((state) => state.user);
  const dispatch = useDispatch();
  const [data, setData] = useState([]);
  const [selectedDoc, setSelectedDoc] = useState(null);
  const [showModal, setShowModal] = useState(false);
  const [numPages, setNumPages] = useState(null);
  const [isFullScreen, setIsFullScreen] = useState(false);
  const docRef = useRef(null);


  const addWatermarkToPdf = async (uploadedPdfFile, watermarkText) => {
    try {
      const pdfDoc = await PDFDocument.load(uploadedPdfFile);
  
      const font = await pdfDoc.embedFont(PDFDocument.Font.Helvetica);
      const textSize = 50;
  
      for (let i = 0; i < pdfDoc.getPageCount(); i++) {
        const page = pdfDoc.getPage(i);
        const textWidth = font.widthOfTextAtSize(watermarkText, textSize);
        const textHeight = font.heightAtSize(textSize);
        const textX = (page.getWidth() - textWidth) / 2;
        const textY = (page.getHeight() - textHeight) / 2;
        page.drawText(watermarkText, {
          x: textX,
          y: textY,
          size: textSize,
          font: font,
          color: rgb(0.5, 0.5, 0.5),
        });
      }
  
      const pdfBytes = await pdfDoc.save();
      return pdfBytes;
    } catch (error) {
      console.error("Failed to add watermark:", error);
      toast.error("Failed to add watermark to the PDF");
      return null;
    }
  };
  // Usage example
  const watermarkText = "Confidential";
  

  const getAllDoc = async () => {
    try {
      dispatch(showLoading());
      const response = await api.get(`/api/user/inbox`, {
        headers: {
          Authorization: token,
        },
      });

      dispatch(hideLoading());
      if (response.status === 200) {
        setData(response.data?.userDocuments);
      }
    } catch (error) {
      toast.error(getError(error));
      dispatch(hideLoading());
    }
  };

  useEffect(() => {
    getAllDoc();
  }, [token]);

  const handleViewDoc = async(data) => {
    // const modifiedPdfBytes = await addWatermarkToPdf(uploadedPdfFile, watermarkText);

    setSelectedDoc(data);
    setShowModal(true);
  };

  const handleCloseModal = () => {
    setShowModal(false);
    setSelectedDoc(null);
  };

  const enterFullScreen = () => {
    if (docRef.current) {
      const doc = docRef.current;
      if (doc.requestFullscreen) {
        doc.requestFullscreen();
      } else if (doc.mozRequestFullScreen) { /* Firefox */
        doc.mozRequestFullScreen();
      } else if (doc.webkitRequestFullscreen) { /* Chrome, Safari and Opera */
        doc.webkitRequestFullscreen();
      } else if (doc.msRequestFullscreen) { /* IE/Edge */
        doc.msRequestFullscreen();
      }
      setIsFullScreen(true);
    }
  };

  const exitFullScreen = () => {
    if (document.exitFullscreen) {
      document.exitFullscreen();
    } else if (document.mozCancelFullScreen) { /* Firefox */
      document.mozCancelFullScreen();
    } else if (document.webkitExitFullscreen) { /* Chrome, Safari and Opera */
      document.webkitExitFullscreen();
    } else if (document.msExitFullscreen) { /* IE/Edge */
      document.msExitFullscreen();
    }
    setIsFullScreen(false);
  };

  useEffect(() => {
    const handleFullScreenChange = () => {
      if (!document.fullscreenElement) {
        setIsFullScreen(false);
        handleCloseModal();
      }
    };

    document.addEventListener('fullscreenchange', handleFullScreenChange);
    document.addEventListener('webkitfullscreenchange', handleFullScreenChange);
    document.addEventListener('mozfullscreenchange', handleFullScreenChange);
    document.addEventListener('MSFullscreenChange', handleFullScreenChange);

    return () => {
      document.removeEventListener('fullscreenchange', handleFullScreenChange);
      document.removeEventListener('webkitfullscreenchange', handleFullScreenChange);
      document.removeEventListener('mozfullscreenchange', handleFullScreenChange);
      document.removeEventListener('MSFullscreenChange', handleFullScreenChange);
    };
  }, []);

  useEffect(() => {
    if (showModal && selectedDoc) {
      enterFullScreen();
    }
  }, [showModal, selectedDoc]);

  const onDocumentLoadSuccess = ({ numPages }) => {
    console.log(numPages)
    setNumPages(numPages);
  };

  return (
    <section className="d-flex justify-content-center align-items-center custom-section">
      <Container className="p-3 rounded-4 shadow bg-light">
        <h5 className="mb-4 text-center fw-bold">Inbox</h5>
        <Table responsive>
          <thead>
            <tr>
              <th>Sr.no</th>
              <th>Sent by</th>
              <th>Email</th>
              <th>Sent at</th>
              <th>Expires at</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {data.map((user, index) => (
              <tr key={index}>
                <td>{index + 1}</td>
                <td>{user?.sentBy?.firstname} {user?.sentBy?.lastname}</td>
                <td>{user?.sentBy?.email}</td>
                <td>{new Date(user?.createdAt).toLocaleDateString('en-GB')}{' '}
                  {new Date(user?.createdAt).toLocaleTimeString('en-GB')}
                </td>
                <td>{new Date(user?.expiresAt).toLocaleDateString('en-GB')}{' '}
                  {new Date(user?.expiresAt).toLocaleTimeString('en-GB')}
                </td>
                <td>
                  <Button
                    variant="primary"
                    className="rounded-pill"
                    onClick={() => handleViewDoc(user?.content)}
                  >
                    View Doc
                  </Button>
                </td>
              </tr>
            ))}

            {data?.length > 0 ? null :
              <tr className='text-center'>
                <td colSpan={6}>
                  Nothing here
                </td>
              </tr>
            }
          </tbody>
        </Table>

        <Modal   show={showModal} onHide={handleCloseModal} size="lg" style={{ cursor: 'not-allowed' }}>
          <Modal.Header closeButton>
            <Modal.Title>View Document</Modal.Title>
          </Modal.Header>
          <Modal.Body >
            {selectedDoc &&
               <div id='pdf-viewer' ref={docRef} style={{ position: 'relative',overflowY:'scroll' }}>
               <div className="watermark">
                 
                 {new Array([0.1,1,2,3,4,5,6,7,8,9,10].map((item,i)=>(
                   <div  style={{top:`${item*10}%`}}  className={`watermark-text-${item} watermark-text`}>
                    SecuShare  SecuShare  SecuShare  SecuShare  SecuShare  SecuShare  SecuShare 
                    </div>


                 )))}
                   {/* <div  className="watermark-text-2">SecuShare</div>
                   <div  className="watermark-text-3">SecuShare</div>
                   <div  className="watermark-text-4">SecuShare</div> */}
                   
                 
               </div>

               <div className="document-container">
  <Document file={selectedDoc} onLoadSuccess={onDocumentLoadSuccess} onLoadError={console.error}>
    {Array.from(new Array(numPages), (el, index) => (
      <Page key={index} pageNumber={index + 1} />
    ))}
  </Document>
</div>


             </div>
            }
          </Modal.Body>
        </Modal>
      </Container>
    </section>
  );
}

export default Inbox;
