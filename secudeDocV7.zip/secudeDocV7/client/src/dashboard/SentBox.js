import React, { useState, useEffect } from 'react';
import { Button, Container, Table, Modal } from 'react-bootstrap';
import { useDispatch, useSelector } from 'react-redux';
//import 'react-pdf/dist/esm/Document.css'; 
import { hideLoading, showLoading } from '../features/loadingSlice';
import { getError } from '../utils/getError';
import toast from 'react-hot-toast';
import api from '../utils/axios';


function SentBox() {

  const { token } = useSelector((state) => state.user);
  const dispatch = useDispatch();
  const [data, setData] = useState([]);
  const [selectedDoc, setSelectedDoc] = useState(null);
  const [showModal, setShowModal] = useState(false);
  const [file, setFile] = useState(null);


  useEffect(() => {
    const getAllDoc = async () => {
      try {
        dispatch(showLoading());
        const response = await api.get("/api/user/documents", {
          headers: {
            Authorization: token,
          },
        });

        dispatch(hideLoading());
        console.log(response);

        if (response.status === 200) {
          setData(response.data?.userDocuments);
        }
      } catch (error) {
       toast.error(getError(error));
        dispatch(hideLoading());
      }
    };

    getAllDoc();
  }, [token]);

  const handleViewDoc = (data) => {
    setSelectedDoc(data);
    setShowModal(true);
  };

  const handleCloseModal = () => {
    setShowModal(false);
 
  };



  return (
    <section className="d-flex justify-content-center align-items-center custom-section">
      <Container className="p-3 rounded-4 shadow bg-light">
        <h5 className="mb-4 text-center fw-bold">Sent Box</h5>
        <Table responsive>
          <thead>
            <tr>
              <th>Sr.no</th>
              <th>Sent to</th>
              
              <th>Email</th>
              <th>Sent at</th>
              <th>Expires at</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {data.map((user, index) => (
              <tr key={index}>
                <td>{index + 1}</td>
                <td>{user?.sentTo?.firstname} {user?.sentTo?.lastname}</td>
                <td>{user?.sentTo?.email}</td>
               <td> {new Date(user?.createdAt).toLocaleDateString('en-GB')}{' '}
                    {new Date(user?.createdAt).toLocaleTimeString('en-GB')}
               </td>
               <td> {new Date(user?.expiresAt).toLocaleDateString('en-GB')}{' '}
                    {new Date(user?.expiresAt).toLocaleTimeString('en-GB')}
               </td>
                 
                <td>
                  <Button
                    variant="primary"
                    className="rounded-pill"
                    onClick={() => handleViewDoc(user?.content)}
                  >
                    View Doc
                  </Button>
                </td>
              </tr>
            ))}

{data?.length > 0 ?null :
<tr className='text-center'>
  <td colSpan={6}>
    Nothing here
  </td>
</tr>

}

          </tbody>
        </Table>

        <Modal show={showModal} onHide={handleCloseModal} size="lg" style={{cursor:'not-allowed'}}>
          <Modal.Header closeButton>
            <Modal.Title>View Document</Modal.Title>
          </Modal.Header>
          <Modal.Body onCopy={(e) => e.preventDefault()}>
         
    {selectedDoc ? (
      <iframe
      onCopy={(e) => e.preventDefault()}
        title="PDF Viewer"
        src={`https://docs.google.com/gview?url=${encodeURIComponent(selectedDoc)}&embedded=true`}
        style={{ width: '100%', height: '600px', border: 'none',cursor:'not-allowed' }}
        sandbox="allow-same-origin allow-scripts "
      />
    ) : (
      <p>No document selected</p>
    )}
  </Modal.Body>

          {/* <Modal.Body>
            <p>{selectedDoc}</p>
            {selectedDoc && (
              <Document file={{ url: selectedDoc }}>
                <Page pageNumber={1} />
              </Document>
            )}
          </Modal.Body> */}
        </Modal>

        </Container>
        </section>
  )
}

export default SentBox