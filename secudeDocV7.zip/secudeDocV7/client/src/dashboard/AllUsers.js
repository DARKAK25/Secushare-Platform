import React, { useEffect, useState } from "react";
import { Container, Table, Button, Modal, Form,Row,Col,InputGroup } from "react-bootstrap";
import { useDispatch, useSelector } from "react-redux";
import { hideLoading, showLoading } from "../features/loadingSlice";
import api from "../utils/axios";
import { getError } from "../utils/getError";
import {FaSearch} from 'react-icons/fa'


function AllUsers() {
  const { token } = useSelector((state) => state.user);
  const dispatch = useDispatch();
  const [data, setData] = useState([]);
  const [selectedUser, setSelectedUser] = useState(null);
  const [showModal, setShowModal] = useState(false);
  const [file, setFile] = useState(null);
  const [loading,setLoading] = useState(false);
  const [hour, setHour] = useState(null);
  const [minute, setMinute] = useState(null);
  const [query,setQuery] = useState('')
  const [searchInput,setSearchInput] = useState('')
  
  const handleHourChange = (e) => {
    const value = e.target.value;
    if (value >= 0 && value <= 23) {
      setHour(value);
    }
  };

  const handleMinuteChange = (e) => {
    const value = e.target.value;
    if (value >= 0 && value <= 59) {
      setMinute(value);
    }
  };

  const getAllUsers = async () => {
    try {
      dispatch(showLoading());
      const response = await api.get(`/api/user/all-users/?keyword=${query}`, {
        headers: {
          Authorization: token,
        },
      });

      dispatch(hideLoading());

      if (response?.status === 200) {
        setData(response?.data?.users);
      }
    } catch (error) {
      getError(error);
      
      dispatch(hideLoading());
    }
  };

  useEffect(() => {
   

    getAllUsers();
  }, [token,query]);

  const handleSendDocClick = (user) => {
    setSelectedUser(user);
  
    console.log(user);
    setShowModal(true);
  };

  const handleCloseModal = () => {
    setShowModal(false);
    setFile(null);
    setHour(null)
    setMinute(null)
  };

  const handleFileChange = (e) => {
    setFile(e.target.files[0]);
  };

  const handleUploadDocument = async (e) => {
    e.preventDefault();
    try {
      const formData = new FormData();
      formData.append("pdfFile", file);
      formData.append("hour", hour); 
      formData.append("minute", minute)
      formData.append("sentTo", selectedUser?._id)
      setLoading(true)
      const response = await api.post("/api/user/upload", formData, {
        headers: {
          "Content-Type": "multipart/form-data",
          Authorization: token,
        }
      });
      setLoading(false)
      console.log("Upload response:", response.data);

      handleCloseModal();
    } catch (error) {
      setLoading(false);
      // getError(error);
      console.error("Error uploading document:", error);
    }
  };
  
  // const secretKey = "secureDoc"



  // const handleUploadDocument = async () => {
  //   try {
  //     const fileData = await readFileAsArrayBuffer(file);
  
  //     const wordArray = CryptoJS.lib.WordArray.create(fileData);
  
  //     const secretKey = 'SecureDoc';
  //     const encryptedFile = CryptoJS.AES.encrypt(wordArray, secretKey).toString();
  
  //     const encryptedFileBlob = new Blob([encryptedFile], { type: 'application/octet-stream' });
  
  //     const formData = new FormData();
  //     formData.append("pdfFile", encryptedFileBlob, "encrypted.pdf"); // Specify the file name
  
  //     const response = await api.post("/api/user/upload", formData, {
  //       headers: {
  //         Authorization: token,
  //       },
  //     });
  
  //     console.log("Upload response:", response.data);
  //     handleCloseModal();
  //   } catch (error) {
  //     console.error("Error handling document upload:", error);
  //   }
  // };
  
  // const readFileAsArrayBuffer = (file) => {
  //   return new Promise((resolve, reject) => {
  //     const reader = new FileReader();
  
  //     reader.onload = (event) => {
  //       resolve(event.target.result);
  //     };
  
  //     reader.onerror = (error) => {
  //       reject(error);
  //     };
  
  //     reader.readAsArrayBuffer(file);
  //   });
  // };
  
  
  
  

  return (
    <section className="d-flex justify-content-center align-items-center custom-section">
      <Container className="p-3 rounded-4 shadow bg-light">
<Row>
  <Col>
  <h5 className="mb-4 text-center fw-bold">All Users</h5>
  </Col>
  <Col>
<InputGroup className=" shadow" style={{maxWidth:'450px',maxHeight:'2rem'}} >
  <Form.Control
    aria-label="Search Input"
    placeholder="Search"
    type="search"
    value={searchInput}
    onChange={(e) => {setSearchInput(e.target.value);
      setQuery(e.target.value)
  }}
    onKeyDown={(e) => {
      if (e.key === 'Enter') {
        setQuery(searchInput);
      
      }
    }}
    
  />
  <InputGroup.Text
  className=" bg-white"
    style={{ cursor: "pointer" }}
    onClick={() => {
      setQuery(searchInput);
    
    }}
     >
    <FaSearch />
  </InputGroup.Text>
</InputGroup>

</Col>

</Row>

      

        <Table responsive>
          <thead>
            <tr>
              <th>Sr.no</th>
              <th>First Name</th>
              <th>Last Name</th>
              <th>Email</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {data?.length >0 && data?.map((user, index) => (
              <tr key={index}>
                <td>{index + 1}</td>
                <td>{user?.firstname}</td>
                <td>{user?.lastname}</td>
                <td>{user?.email}</td>
                <td>
                  <Button
                    variant="primary"
                    className="rounded-pill"
                    onClick={() => handleSendDocClick(user)}
                  >
                    Send Doc
                  </Button>
                </td>
              </tr>
            ))}
          </tbody>
        </Table>

        {/* Modal for sending documents */}
        <Modal show={showModal} onHide={handleCloseModal}>
          <Modal.Header closeButton>
            <Modal.Title>Send Document to {selectedUser?.firstname}</Modal.Title>
          </Modal.Header>
          <Modal.Body>
            <Form onSubmit={handleUploadDocument}>
              <Form.Group controlId="formFile" className="mb-3">
                <Form.Label>Choose PDF File</Form.Label>
                <Form.Control type="file" accept=".pdf" onChange={handleFileChange} />
              </Form.Group>

              <Form.Group controlId="formTime" className="mb-3">
            <Form.Label>Select Expiry Time</Form.Label>
            <div className="d-flex">
            
              <Form.Control  required type="number" min="0" max="23" step='1' placeholder="Hour" value={hour} onChange={handleHourChange} />
              <span className="mx-2">:</span>
              <Form.Control required type="number" min="0" max="59" step='2' placeholder="Minute" value={minute} onChange={handleMinuteChange} />
            </div>
          </Form.Group>
          <Row>
            <Col className="text-end">
          <Button variant="secondary" onClick={handleCloseModal}>
              Close
            </Button>
           
            <Button variant="primary" type="submit" className="mx-2" >
             {loading?'Sending...':'Send Document'} 
            </Button>
            </Col>
            </Row>
            </Form>
          </Modal.Body>
       
        </Modal>
      </Container>
    </section>
  );
}

export default AllUsers;
