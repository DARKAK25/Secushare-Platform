import toast from "react-hot-toast";

export const getError = (error) => {
  const errorMessage = error?.data?.error ||
                      error?.error ||
                      error?.data?.message ||
                      (error.response?.message || error.response?.data?.message || error.response?.data?.error ||error.response?.data?.error?.message || error.response) ||
                      error.message ||
                      'Something went wrong';

  toast.error(errorMessage);

  
  console.log({ error });

  return null; 
};



