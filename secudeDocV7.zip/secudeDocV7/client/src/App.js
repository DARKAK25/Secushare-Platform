import { useEffect } from 'react';
import './App.css';
import Aos from 'aos';
import { Toaster } from 'react-hot-toast';
import {  Route, Routes,  } from 'react-router-dom';
import Header from './components/Header';
import AuthPage from './pages/AuthPage';
import NotFound from './pages/NotFound';
import HomePage from './pages/HomePage';
import ProtectedRoute from './utils/ProtectedRoute';
import Profile from './dashboard/Profile';
import AllUsers from './dashboard/AllUsers';
import Inbox from './dashboard/Inbox';
import SentBox from './dashboard/SentBox';

function App() {
  useEffect(()=>{
        
    Aos.init();

},[]);

const protectedRoutes = [
    
   { path: '/dashboard/profile', element: <Profile /> },
   { path: '/dashboard/all-users', element: <AllUsers /> },
   { path: '/dashboard/sent', element: <SentBox /> },
   { path: '/dashboard/inbox', element: <Inbox /> },
  // { path: '/dashboard/applications', element: <Applications /> },
  
];

  return (
    <>
    <Toaster position="top-center"  reverseOrder={false} toastOptions={{duration: 5000}}/>
   <Header/>
    <Routes>
    {protectedRoutes.map((route, index) => (
        <Route path={route.path} key={index}  element={<ProtectedRoute>{route.element}</ProtectedRoute>} />
        ))}
      <Route path='/' element={<HomePage/>}  />   
      <Route path='/auth/login' element={<AuthPage/>}  />   
      <Route path='/auth/reg' element={<AuthPage/>}  />   
      <Route path='*' element={<NotFound/>}  />   
    </Routes>
    </>
  );
}

export default App;
