import React from "react";
import {
  Button,
  Container,
  Dropdown,
  DropdownButton,
  Nav,
  Navbar,
} from "react-bootstrap";
import { FaUser } from "react-icons/fa6";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import './Header.css'
import { logout } from "../features/logoutSlice";

function Header() {
  const navigate = useNavigate();
 const dispatch = useDispatch();
  const userToken = useSelector((state) => state.user.token);
  const user = useSelector((state) => state.user.user);
  console.log(userToken);

  const userIcon = (
    <span>
      <FaUser />
    </span>
  );

   const handleLogout= () =>{
       dispatch(logout());
   }
  return (
    <Navbar className="bg-body-transparent glass-morf" sticky="top" style={{ height: "60px" }}>
      <Container>
        <Navbar.Brand
          className="fw-bold fs-3 text-white"
          style={{ cursor: "pointer" }}
          onClick={() => navigate("/")}
        >
          LOGO
        </Navbar.Brand>
        <Nav>
          <Nav.Link onClick={() => navigate("/")} className="fw-bold text-white fs-5">
            Home
          </Nav.Link>
          {/* <Nav.Link
            onClick={() => navigate("/pricing")}
            className="fw-bold fs-5"
          >
            Pricing
          </Nav.Link> */}
        </Nav>

         {userToken ? (
          <div>
          <DropdownButton variant="light"  id="dashboard-dropdown"  title={userIcon}>
            <Dropdown.ItemText className="fw-bold text-muted">{user?.firstname + " " +user?.lastname}</Dropdown.ItemText>
            <Dropdown.Item className="fw-bold " as="button" onClick={()=>navigate('/dashboard/profile')}>Profile</Dropdown.Item>
            <Dropdown.Item className="fw-bold " as="button" onClick={()=>navigate('/dashboard/all-users')}>All Users</Dropdown.Item>
            <Dropdown.Item className="fw-bold " as="button" onClick={()=>navigate('/dashboard/sent')}>Sent</Dropdown.Item>
            <Dropdown.Item className="fw-bold " as="button" onClick={()=>navigate('/dashboard/inbox')}>Inbox
             {/* {user?.inboxCount > 0 &&<span className="px-2 rounded-pill" style={{backgroundColor:'red',fontSize:'0.8rem'}}>{user?.inboxCount}</span>} */}
             </Dropdown.Item>
            <Dropdown.Item className="fw-bold " as="button" onClick={handleLogout}>Log Out</Dropdown.Item>
          </DropdownButton>
          </div>
        ) : (
          <Button
            variant="dark"
            onClick={() => navigate("/auth/login")}
            className="rounded-pill px-4 fw-bold"
          >
            Login
          </Button>
        )} 

        
      </Container>
    </Navbar>
  );
}

export default Header;
